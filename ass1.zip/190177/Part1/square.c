#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>   


int main( int argc, char *argv[] )
{


	int n=argc;
    if(n==1)
    {
        printf("UNABLE TO EXECUTE");
    }
    long long int ho=atoll(argv[1])*atoll(argv[n-1]);
     if(ho<0)
    {
         printf("UNABLE TO EXECUTE");
         exit(1);
    }
    if(n==2)
    {
       printf("%lld\n",ho);
    }
    else
    {
        sprintf (argv[n-1], "%lli", ho);      
         if(execv(argv[1],argv+1)==-1)
        {
            printf("UNABLE TO EXECUTE");
        }
    }
	return 0;
}
