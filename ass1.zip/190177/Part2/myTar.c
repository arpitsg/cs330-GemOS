#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
 #include<string.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

/* struct dirent {
    ino_t          d_ino;        inode number
    off_t          d_off;        offset to the next dirent 
    unsigned short d_reclen;     length of this record 
    unsigned char  d_type;       type of file; not supported
                                   by all file system types 
    char           d_name[256];  filename 
*/

int main(int argc, char *argv[] )
{
	DIR *dir;
	struct dirent *sd;
 	struct stat file_info;
	if( strcmp( "-c",argv[1])==0 )
	{
		if(argc!=4)
		{
			printf("Failed to complete creation operation");
			exit(1);
		}
		dir=opendir(argv[2]);
		
		
		if(dir==NULL)
		{
			printf("Failed to complete creation operation");
			exit(1);
		}
		if(chdir(argv[2])==-1)
		{
			printf("Failed to complete creation operation");
			exit(1);
		}
		
		char tar_file_address[256];
		sprintf(tar_file_address,"./%s",argv[3]);
		int fd=open(tar_file_address,O_RDWR|O_CREAT,0666);
		if(fd==-1)
		{
			printf("Failed to complete creation operation");
			exit(1);
		}
		while(((sd=readdir(dir))!=NULL))
		{
			lstat(sd->d_name, &file_info);  
			if(sd->d_type != DT_DIR && strcmp( sd->d_name,argv[3])!=0  ) 
			{	
				char c[10000];
				char temp_current_file_address[512];
				sprintf(temp_current_file_address,"./%s",sd->d_name);
				int fd_cur= open(temp_current_file_address,O_RDONLY);		
				if(fd_cur==-1)
				{
					printf("Failed to complete creation operation");
					exit(1);
				}		
			    if(write(fd,sd->d_name,256)==-1)
				{
					printf("Failed to complete creation operation");
					exit(1);
				}
				long sizeoffile = lseek(fd_cur,0,SEEK_END);
				lseek(fd_cur,0,SEEK_SET);
				if(sizeoffile<0){continue;}
				char info[256];
				sprintf(info,"%ld",sizeoffile);
				if(write(fd,info,256)==-1)
			    {
					  printf("Failed to complete creation operation");
					  exit(1);
			    }
				struct stat finfo_cur;
				if(fstat(fd_cur, &finfo_cur)==-1)
				{
					 printf("Failed to complete creation operation");
					 exit(1);

				}
				sprintf(info,"%ld",finfo_cur.st_size);
				if(write(fd,info,256)==-1)
				{
					 printf("Failed to complete creation operation");
					 exit(1);
				}
				int x;
				while((x=read(fd_cur, c, 10000))>0)
				{
					write(fd,c,x);
				}
				close(fd_cur);
			}
		}
			closedir(dir);                  
	}
	if( strcmp( "-l",argv[1])==0 )
	{
		if(argc!=3)
		{
			printf("Failed to complete list operation");
			exit(1);
		}
		int fd=open(argv[2],O_RDWR);
		if(fd==-1)
		{
			printf("Failed to complete list operation");
			exit(1);
		}
		char dir_address[256];
		long i = strlen(argv[2]) -1;
		
		for(; i>=0; i--)  
    	{
        	if (argv[2][i] == '/')
        	{
				i++;
				break;
			}
        }
		if(i>0)
	    {
			strncpy(dir_address,argv[2],i);
			dir_address[i]='\0';
			if(chdir(dir_address)==-1)
			{
				printf("Failed to complete list operation");
				exit(1);
			}
		}
		//	printf("%ld\n",i);
		int fd_list=open("tarStructure",O_RDWR|O_CREAT,0644);
		if(fd_list==-1)
		{
				printf("Failed to complete list operation");
				exit(1);
		}

		char c[1];
		long long int total_bits=0;
		long long int tot_file=0;
		struct stat finfo;
		if(fstat(fd, &finfo)==-1)
		{
				printf("Failed to complete list operation");
				exit(1);
		}
		
		total_bits=finfo.st_size;
		char info[1024];
		sprintf(info,"%lld\n",total_bits);
		if(write(fd_list,info,strlen(info))==-1)
		{
			printf("Failed to complete list operation");
			exit(1);
		}
		char file_name[512];
		char file_name_address_dump[1024];
		char file_size[256];
		char temp[256];
		while(1)
		{	
				if(read(fd,file_name,256)!=256)
				{
					break;
				}
				if(read(fd,file_size,256)!=256)
				{
					//error
				}
				if(read(fd,temp,256)!=256)
				{
					//error
				}
				long int file_size_num=0;
				file_size_num=0;
				int itr=0;
				while(itr<256&&file_size[itr]!='\0')
				{
					file_size_num=file_size_num*10+file_size[itr]-'0';
					itr++;
				}
				lseek(fd,file_size_num,SEEK_CUR);
				// while(file_size_num && read(fd,c,1)>0)
				// {
				// 	file_size_num--;
				// }
				tot_file+=1;
			}
			sprintf(info,"%lld\n",tot_file);
		    write(fd_list,info,strlen(info));

			if(lseek(fd,0,SEEK_SET)==-1)
			{
				printf("Failed to complete list operation");
				exit(1);
			}
			while(1)
			{
				if(read(fd,file_name,256)!=256)
				{
					break;
				}
				if(read(fd,file_size,256))
				{
					//error
				}
				if(read(fd,temp,256))
				{
					//error
				}
				sprintf(info,"%s ",file_name);

		        if(write(fd_list,info,strlen(info))==-1)
				{
						printf("Failed to complete list operation");
						exit(1);
				}
				sprintf(info,"%s\n",temp);

		        if(write(fd_list,info,strlen(info))==-1)
				{
						printf("Failed to complete list operation");
						exit(1);
				}
				long int file_size_num=0;
				file_size_num=0;
				int itr=0;
				while(itr<256&&file_size[itr]!='\0')
				{
					file_size_num=file_size_num*10+file_size[itr]-'0';
					itr++;
				}
				if(lseek(fd,file_size_num,SEEK_CUR)==-1)
				{
						printf("Failed to complete list operation");
						exit(1);
				}
				// while(file_size_num && read(fd,c,1)>0)
				// {
				// 	file_size_num--;
				// }
				tot_file+=1;
			}

	
	}
	if(strcmp( "-d",argv[1])==0)
	{
		if(argc!=3)
		{
			printf("Failed to complete extraction operation");
			exit(1);
		}
			char dir_name[256];
			char dir_address[256];
		    char* name;
			char * token;
			int fd=open(argv[2],O_RDWR);
			if(fd==-1)
			{
				printf("Failed to complete extraction operation");
				exit(1);
			}
		 long int i = strlen(argv[2]) -1;
		
		for(; i>=0; i--)  
    	{
        	if (argv[2][i] == '/')
        	{
				i++;
				break;
			}
        }
	
		if(i>0)
	    {
			strncpy(dir_address,argv[2],i);
			dir_address[i]='\0';
		
			if(chdir(dir_address)==-1)
			{
				printf("Failed to complete extraction operation");
				exit(1);
			}
		}
			
			token=strtok(argv[2],"/");
			if(token==NULL)
			{
				name=argv[2];
			}
			int len=i;
			if(len<0)
				len=0;
			while(token!=NULL)
			{
				name=token;
				token=strtok(NULL,"/");
			}
			name=strtok(name,".");
			sprintf(dir_address+len,"%s%s",name,"Dump");

			mkdir(dir_address,0777);
	
			char c[10001];
			char file_name[512];
			char file_name_address_dump[1024];
			int fd_cur;
			char file_size[256];
			char temp[256];
			while(1)
			{
				if(read(fd,file_name,256)!=256)
				{
					break;
				}
				if(read(fd,file_size,256)==-1)
				{
					printf("Failed to complete extraction operation");
				    exit(1);
				}

				if(read(fd,temp,256)==-1)
				{
					printf("Failed to complete extraction operation");
				    exit(1);
				}
				sprintf(file_name_address_dump,"%s%s%s",dir_address,"/",file_name);
				fd_cur=open(file_name_address_dump,O_RDWR|O_CREAT,0644);
				if(fd_cur==-1)
				{
					printf("Failed to complete extraction operation");
				    exit(1);
				}
				long int file_size_num=0;
				file_size_num=0;
				int itr=0;
				while(itr<256&&file_size[itr]!='\0')
				{
					file_size_num=file_size_num*10+file_size[itr]-'0';
					itr++;
				}
				while(read(fd,c,MIN(file_size_num,10000))>0)
				{
					if(write(fd_cur,c,MIN(file_size_num,10000))==-1)
					{
						printf("Failed to complete extraction operation");
						exit(1);
					}
					file_size_num-=MIN(file_size_num,10000);
				}
			}
	}
	if(strcmp( "-e",argv[1])==0)
	{
		if(argc!=4)
		{
			printf("Failed to complete extraction operation");
			exit(1);
		}	
			char indiv_file_name[256];

			char dir_name[256];
			char dir_address[256];
		    char* name;
			int fd=open(argv[2],O_RDWR);
			if(fd==-1)
			{
				printf("Failed to complete extraction operation");
				exit(1);
			}
			long int i = strlen(argv[2]) -1;
			
			for(; i>=0; i--)  
			{
				if (argv[2][i] == '/')
				{
					i++;
					break;
				}
			}
		
			if(i>0)
			{
				strncpy(dir_address,argv[2],i);
				dir_address[i]='\0';
				if(chdir(dir_address)==-1)
				{
					printf("Failed to complete extraction operation");
					exit(1);
				}
			}
			mkdir("IndividualDump",0777);
			char c[10001];
			char file_name[512];
			char file_name_address_dump[1024];
			int fd_cur;
			char file_size[256];
			char temp[256];
			int flag=0;
			while(1)
			{
				if(read(fd,file_name,256)!=256)
				{
					break;
				}
				if(read(fd,file_size,256))
				{
					//error
				}

				if(read(fd,temp,256))
				{
					//error
				}
				sprintf(file_name_address_dump,"./IndividualDump/%s",file_name);
				
				long int file_size_num=0;
				file_size_num=0;
				int itr=0;
				while(itr<256&&file_size[itr]!='\0')
				{
					file_size_num=file_size_num*10+file_size[itr]-'0';
					itr++;
				}
			
				char cur_file_name[1024];
				sprintf(cur_file_name,"%s",file_name);
				if(strcmp(cur_file_name,argv[3])==0)
				{
					flag=1;
					fd_cur=open(file_name_address_dump,O_RDWR|O_CREAT,0644);
					if(fd_cur==-1)
					{
							printf("Failed to complete extraction operation");
							exit(1);
					}
				}
				
				while(read(fd,c,MIN(file_size_num,10000))>0)
				{
					if(flag)
					write(fd_cur,c,MIN(file_size_num,10000));
					file_size_num-=MIN(file_size_num,10000);
				}
				if(flag)
				break;
			}
			if(!flag)
			{
				printf("No such file is present in tar file.");
			}
	}
	return 0;
}

