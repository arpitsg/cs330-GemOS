#include "wc.h"
extern struct team teams[NUM_TEAMS];
extern int test;
extern int finalTeam1;
extern int finalTeam2;
int grpA_pipe[2];
int grpB_pipe[2];

int processType = HOST;
const char *team_names[] = {
  "India", "Australia", "New Zealand", "Sri Lanka",   // Group A
  "Pakistan", "South Africa", "England", "Bangladesh" // Group B
};

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void teamPlay(void)
{
    char file_name[100];
    sprintf(file_name,"./test/%d/inp/%s",test,teams[processType].name);
    int fd=open(file_name,O_RDONLY);
    if(fd<0)
    {
        printf("error in fileopen teamplay %s\n",file_name);
    }
    char buf[1],buf2[1];
    while(1)
    {
        if(read(teams[processType].commpipe[0],buf,1)==1)
        {
            if(buf[0]==1)
            {
                exit(0);
            }
            else
            {   
                if(read(fd,buf2,1)<0)
                {
                    printf("error in teamplay read");
                }
               if(write(teams[processType].matchpipe[1],buf2,1)<0)
               {
                 printf("error in teamplay write");
               } 
            }
        }
    }
}

void endTeam(int teamID)
{
  if(write(teams[teamID].commpipe[1],"1",1)!=1)
  {
      printf("error in endTeam");
  }
  
}

int match(int team1, int team2)
{
  //find toss
  int toss=0;
  char buf1[1],buf2[1];
   if(write(teams[team1].commpipe[1],"0",1)!=1)
  {
     printf("error in match-write");
  }
  if(read(teams[team1].matchpipe[0],buf1,1)!=1)
  {
     printf("error in match");
  }
   if(write(teams[team2].commpipe[1],"0",1)!=1)
  {
      printf("error in match-write");
  }
  if(read(teams[team2].matchpipe[0],buf2,1)!=1)
  {
     printf("error in match");
  }
  int x,y;
  toss=buf1[0]-'0'+buf2[0]-'0';
  toss=toss&1;

  if(toss==1)
  {
    x=team1;
    y=team2;
  }
  else
  {
    y=team1;
    x=team2;
  }
  char file_name[160];
  if((team2-team1)>=4)
  {
      sprintf(file_name,"./test/%d/out/%s%c%s%s",test,teams[x].name,'v',teams[y].name,"-Final");
  }

  else
  {
      sprintf(file_name,"./test/%d/out/%s%c%s",test,teams[x].name,'v',teams[y].name);
  }
  
  int fd=open(file_name,O_RDWR|O_CREAT,0666);
  char innings[100];
  
  int score[2],wic[2];
  score[0]=0;
  score[1]=0;
  wic[0]=0;
  wic[1]=0;
  char info[100];
  int last=0;
  int k=0;
  while(k<2)
  {
    sprintf(innings,"Innings%d: %s bats\n",k+1,teams[x].name);
    if(write(fd,innings,strlen(innings))!=strlen(innings))
    {
      printf("Error in match");
    }
    for(int i=0;i<120;i++)
    {
      
      if(write(teams[x].commpipe[1],"0",1)!=1)
      {
         printf("error in match-loop-write");
      }
      if(read(teams[x].matchpipe[0],buf1,1)!=1)
      {
          printf("error in match-loop");
      }
      if(write(teams[y].commpipe[1],"0",1)!=1)
      {
         printf("error in match-loop-write");
      }
      if(read(teams[y].matchpipe[0],buf2,1)!=1)
      {
        printf("error in match-loop");
      }
      if(buf1[0]!=buf2[0])
      {
          score[k]+=buf1[0]-'0';
        if(i==119)
        {
          sprintf(info,"%d:%d*\n",wic[k]+1,score[k]-last);
          write(fd,info,strlen(info)); 
        }
        else if(k==1&&(score[1]>score[0]))
        {
            sprintf(info,"%d:%d*\n",wic[k]+1,score[k]-last);
            write(fd,info,strlen(info)); 
        }
      }
      else
      {
        wic[k]++;
        sprintf(info,"%d:%d\n",wic[k],score[k]-last);
        write(fd,info,strlen(info));
        last=score[k];
      }
      if(wic[k]==10 || ((k==1)&&(score[1]>score[0])))
      {
        break;
      }
    }
    sprintf(info,"%s TOTAL: %d\n",teams[x].name,score[k]);
    write(fd,info,strlen(info));
    swap(&x,&y);
    k++;
    last=0;
  }
  int winner=team1;
  if(score[0]>score[1])
  {
    if(toss)
    {
      winner=team1;
      sprintf(info,"%s beats %s by %d runs\n",teams[team1].name,teams[team2].name,score[0]-score[1]);
      write(fd,info,strlen(info));
    }
    else
    {
      winner=team2;
      sprintf(info,"%s beats %s by %d runs\n",teams[team2].name,teams[team1].name,score[0]-score[1]);
      write(fd,info,strlen(info));
    }
  }
  else if(score[0]<score[1])
  {
    if(!toss)
    {
       winner=team1;
      sprintf(info,"%s beats %s by %d wickets\n",teams[team1].name,teams[team2].name,10-wic[1]);
      write(fd,info,strlen(info));
    }
    else
    {
       winner=team2;
      sprintf(info,"%s beats %s by %d wickets\n",teams[team2].name,teams[team1].name,10-wic[1]);

      write(fd,info,strlen(info));
    }
  }
  else
  {
    sprintf(info,"TIE: %s beats %s\n",teams[team1].name,teams[team2].name);
  }
	return winner;
}

void spawnTeams(void)
{

    //make directory of out in test
    char folder_out[100];
    sprintf(folder_out,"./test/%d/out",test);
    mkdir(folder_out,0777);
   
    //copying names 
    for(int i=0;i<NUM_TEAMS;i++)
    {
      int j=0;
      while(1)
      {
           teams[i].name[j]=team_names[i][j];
           if(team_names[i][j]=='\0')
              break;
            j++;
      }
       if(pipe(teams[i].matchpipe) < 0)
      {
        //error
      }
      if(pipe(teams[i].commpipe) < 0)
      {
        //error
      }
    }
   
    for(int i=0;i<NUM_TEAMS;i++)
    {
      processType=i;
      int  pid=fork();
      if(pid==0)
      {
          teamPlay();
      }
    }

    return;
}

void conductGroupMatches(void)
{

  pipe(grpA_pipe);
  pipe(grpB_pipe);
  int pid1=fork();
  int pid2;
  if(pid1==-1)
  {
    printf("Error");
  }
  if(pid1!=0)
  {
    pid2=fork();
    if(pid2<0)
    {
       printf("Error");
    }
  }
  int wins[NUM_TEAMS];
  for(int i=0;i<NUM_TEAMS;i++)
    wins[i]=0; 
  if(pid1==0)
  {
    //groupA
    int leader=0;
    for(int i=0;i<NUM_TEAMS/2;i++)
    {
      for(int j=i+1;j<NUM_TEAMS/2;j++)
      {
           wins[ match(i,j)]++;
      }
    }
    int ma=0;
    for(int i=0;i<NUM_TEAMS/2;i++)
    {
      if(wins[i]>ma)
      {
        leader=i;
        ma=wins[i];
      }
    }
    for(int i=0;i<NUM_TEAMS/2;i++)
    {
      if(i!=leader)
        endTeam(i);
    }
    // write leader in grpA_pipe
    char buf[1];
    buf[0]=leader+'0';
    if( write(grpA_pipe[1],buf,1)!=1)
    {
      printf("Error");
    }
    
  exit(0);
  }
  if(pid2==0)
  {
    //groupB
        int ma=0;
    int leader=-1;
   for(int i=NUM_TEAMS/2;i<NUM_TEAMS;i++)
    {
      for(int j=i+1;j<NUM_TEAMS;j++)
      {
            wins[ match(i,j)]++;
      }
    }
     char buf[1];
   
    for(int i=NUM_TEAMS/2;i<NUM_TEAMS;i++)
    {
      if(wins[i]>ma)
      {
        leader=i;
        ma=wins[i];
      }
    }
     buf[0]=leader+'0';
    for(int i=NUM_TEAMS/2;i<NUM_TEAMS;i++)
    {
        if(i!=leader)
        endTeam(i);
    }
    if( write(grpB_pipe[1],buf,1)!=1)
    {
      
      printf("Error");
    }
  exit(0);
  }
  if(pid1!=0 && pid2!=0)
  {
       wait(NULL);
        char buf1[1],buf2[1];
      if(read(grpA_pipe[0],buf1,1)!=1)
      {
          printf("error\n");
      }
      if(read(grpB_pipe[0],buf2,1)!=1)
      {
          printf("error\n");
      }
      finalTeam1=buf1[0]-'0';
      finalTeam2=buf2[0]-'0';
      return;
  }
}
