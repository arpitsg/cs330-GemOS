#include<pipe.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>            


// Per process info for the pipe.
struct pipe_info_per_process {

    // TODO:: Add members as per your need...
    // int fd[2];
    int write_open;
    int read_open;
    int pid;
};

// Global information for the pipe.
struct pipe_info_global {

    char *pipe_buff;    // Pipe buffer: DO NOT MODIFY THIS.
    int total_proc;
    int read_ptr;
    int write_ptr;
     int written; 

};
//
// Pipe information structure.
// NOTE: DO NOT MODIFY THIS STRUCTURE.
struct pipe_info 
{
    struct pipe_info_per_process pipe_per_proc [MAX_PIPE_PROC];
    struct pipe_info_global pipe_global;
};

//
// Function to allocate space for the pipe and initialize its members.
struct pipe_info* alloc_pipe_info () {
	
    // Allocate space for pipe structure and pipe buffer.
    struct pipe_info *pipe = (struct pipe_info*)os_page_alloc(OS_DS_REG);
    char* buffer = (char*) os_page_alloc(OS_DS_REG);
    if(pipe==NULL)
    {
        return pipe;
    }
    // Assign pipe buffer.
    pipe->pipe_global.pipe_buff = buffer;
    /**
     *  TODO:: Initializing pipe fields
     *  
     *  Initialize per process fields for this pipe.
     *  Initialize global fields for this pipe.
     */
    pipe->pipe_global.total_proc=1;
    pipe->pipe_global.read_ptr=0;
    pipe->pipe_global.write_ptr=0;
    pipe->pipe_global.written=0;

    for(int i=0;i<MAX_PIPE_PROC;i++)
    {
        pipe->pipe_per_proc[i].write_open=1;
        pipe->pipe_per_proc[i].read_open=1;
        pipe->pipe_per_proc[i].pid=-1;
    }
    struct exec_context *current = get_current_ctx();
    pipe->pipe_per_proc[0].pid=current->pid;
   
    // Return the pipe.
    return pipe;

}

// Function to free pipe buffer and pipe info object.
// NOTE: DO NOT MODIFY THIS FUNCTION.
void free_pipe (struct file *filep) {

    os_page_free(OS_DS_REG, filep->pipe->pipe_global.pipe_buff);
    os_page_free(OS_DS_REG, filep->pipe);

}

// Fork handler for the pipe.
int do_pipe_fork (struct exec_context *child, struct file *filep) 
{
    
    /**
     *  TODO:: Implementation for fork handler
     *
     *  You may need to update some per process or global info for the pipe.
     *  This handler will be called twice since pipe has 2 file objects.
     *  Also consider the limit on no of processes a pipe can have.
     *  Return 0 on success.
     *  Incase of any error return -EOTHERS.
     *
     */
    // printk("called\n");
    if(child==NULL ||filep==NULL)
    {
        return -EOTHERS;
    }
    struct pipe_info* curPipe= filep->pipe;  

    //error
    if(curPipe==NULL)
    {
        return -EOTHERS;
    }
    
    int k=0;
    for(int i=0;i<MAX_PIPE_PROC;i++)
    {
        if(curPipe->pipe_per_proc[i].pid==child->pid)
        {
             k=1;
        }
    }
     
    if(k==0)
    {
        if( curPipe->pipe_global.total_proc ==MAX_PIPE_PROC)
         {
        //   printk("b %d\n",MAX_PIPE_PROC);
        return -EOTHERS;
        }
        // printk("total_proc=%d\n",curPipe->pipe_global.total_proc);
        curPipe->pipe_global.total_proc++;
        // printk("curPipe->pipe_global.total_proc=%d",curPipe->pipe_global.total_proc);
            for(int i=0;i<MAX_PIPE_PROC;i++)
            {
                if(curPipe->pipe_per_proc[i].pid==-1)
                {
                    curPipe->pipe_per_proc[i].pid=child->pid;
                    curPipe->pipe_per_proc[i].write_open=1;
                    curPipe->pipe_per_proc[i].read_open=1;
                    break;
                }
            }
    }

    return 0;
}

// Function to close the pipe ends and free the pipe when necessary.
long pipe_close (struct file *filep) 
{

    /**
     *  TODO:: Implementation of Pipe Close
     *
     *  Close the read or write end of the pipe depending upon the file
     *      object's mode.
     *  You may need to update some per process or global info for the pipe.
     *  Use free_pipe() function to free pipe buffer and pipe object,
     *      whenever applicable.
     *  After successful close, it return 0.
     *  Incase of any error return -EOTHERS.
     */
    if(filep==NULL)
    {
        return -EOTHERS;
    }

    int ret_value;
    struct pipe_info* curPipe= filep->pipe;
    struct exec_context *current = get_current_ctx();
      if(current==NULL||curPipe==NULL)
    {
        return -EOTHERS;
    }
   
    


    for(int i=0;i<MAX_PIPE_PROC;i++)
    {

        if(curPipe->pipe_per_proc[i].pid==current->pid)
        {
                        // printk("mode->%d, O_WRITE=%d, O_READ=%d\n",filep->mode,O_WRITE,O_READ);

            if(filep->mode & O_WRITE)
            {
                if(curPipe->pipe_per_proc[i].write_open==0)
                {
                      return -EOTHERS;
                }
                curPipe->pipe_per_proc[i].write_open=0;
                //  printk("Closed write\n");
            }
            if(filep->mode &  O_READ)
            {
                 if(curPipe->pipe_per_proc[i].read_open==0)
                {
                      return -EOTHERS;
                }
                curPipe->pipe_per_proc[i].read_open=0;
                //  printk("Closed read\n");
            }
            if(curPipe->pipe_per_proc[i].write_open==0  && curPipe->pipe_per_proc[i].read_open==0 )
            {
                curPipe->pipe_global.total_proc--;
                curPipe->pipe_per_proc[i].pid=-1;
                if( curPipe->pipe_global.total_proc==0)
                {
                     free_pipe(filep);
                }
            }
        }
    }
    // Close the file and return.
    ret_value = file_close(filep);         // DO NOT MODIFY THIS LINE.
    // And return.
    return ret_value;
}

// Check whether passed buffer is valid memory location for read or write.
int is_valid_mem_range (unsigned long buff, u32 count, int access_bit) {

    /**
     *  TODO:: Implementation for buffer memory range checking
     *
     *  Check whether passed memory range is suitable for read or write.
     *  If access_bit == 1, then it is asking to check read permission.
     *  If access_bit == 2, then it is asking to check write permission.
     *  If range is valid then return 1.
     *  Incase range is not valid or have some permission issue return -EBADMEM.
     *
     */
    //  printk("0");
    struct exec_context *current = get_current_ctx();

    struct vm_area *vm =current->vm_area;
    struct mm_segment mm[MAX_MM_SEGS];
    int isvalid=0;
    // printk("1");
    for(int i=0;i<MAX_MM_SEGS;i++)
    {
        //  printk("%d",i);
        mm[i]=current->mms[i];

        if(i<(MAX_MM_SEGS-1) && buff>=mm[i].start && (buff+count)<mm[i].next_free && mm[i].access_flags&access_bit!=0)
        {
            // printk("MAX_MM_SEGS=%x , %x\n",mm[i].start,mm[i].next_free);
            isvalid=1;
        }
        //
        else if(i==(MAX_MM_SEGS-1) && buff>=mm[i].start && (buff+count)<=mm[i].end  && mm[i].access_flags&access_bit!=0 )
        {
            //  printk("MAX_MM_SEGS=%d\n",i);
             isvalid=1;
        }

    }

    while(vm!=NULL && isvalid==0)
    {
        // printk("3");
         if(buff>=vm->vm_start && (buff+count)<=vm->vm_end && vm->access_flags&access_bit!=0 )
        {
            isvalid=1;
        }
         vm=vm->vm_next;
    }
    int ret_value = -EBADMEM;
    if(isvalid==1)
    ret_value=1;
    // Return the finding.
    //   printk("4");
    return ret_value;
}

// Function to read given no of bytes from the pipe.
int pipe_read (struct file *filep, char *buff, u32 count) {

    /**
     *  TODO:: Implementation of Pipe Read
     *
     *  Read the data from pipe buffer and write to the provided buffer.
     *  If count is greater than the present data size in the pipe then just read
     *       that much data.
     *  Validate file object's access right.
     *  On successful read, return no of bytes read.
     *  Incase of Error return valid error code.
     *       -EACCES: In case access is not valid.
     *       -EINVAL: If read end is already closed.
     *       -EOTHERS: For any other errors.
     *
     */
    ////
    // printk("read called\n");//
      if(filep==NULL)
    {
        return -EOTHERS;
    }
    if(buff==NULL)
    {
        return -EOTHERS;
    }
    
    struct exec_context *current = get_current_ctx();

    if(current==NULL)
    {
        return -EOTHERS;
    }

    int bytes_read = 0;
    struct pipe_info* curPipe= filep->pipe;
   
    int cur_read=curPipe->pipe_global.read_ptr;
    int cur_write=curPipe->pipe_global.write_ptr;
    char *cur_buffer=curPipe->pipe_global.pipe_buff;
    int buf_size=MAX_PIPE_SIZE;
    int data_written=curPipe->pipe_global.written;

    if(count>=(data_written))
        count=data_written;

    if(is_valid_mem_range((long unsigned int)buff,count,1)!=1)
    {
        return -EACCES;
    }

    int flag=0;
    for(int i=0;i<MAX_PIPE_PROC;i++)
    {
        if(filep->pipe->pipe_per_proc[i].pid==current->pid)
        {
            flag++;
            if(filep->pipe->pipe_per_proc[i].read_open==0)
            {
                return -EINVAL;
            }
        }
    }
    if(flag==0)
    {
        return -EOTHERS;
    }

    // printk("From do_read: readpointer=%d, writepointer=%d , written=%d , count=%d \n",cur_read,cur_write,curPipe->pipe_global.written,count);
     bytes_read=0;
    while((bytes_read<count))
    {
        buff[bytes_read]=cur_buffer[cur_read];
        cur_read++;
        bytes_read++;
        curPipe->pipe_global.written--;
        cur_read%=MAX_PIPE_SIZE;
    }

    curPipe->pipe_global.read_ptr=cur_read;
    // Return no of bytes read.
    return bytes_read;

}

// Function to write given no of bytes to the pipe.
int pipe_write (struct file *filep, char *buff, u32 count) {
    /**
     *  TODO:: Implementation of Pipe Write
     *
     *  Write the data from the provided buffer to the pipe buffer.
     *  If count is greater than available space in the pipe then just write data
     *       that fits in that space.
     *  Validate file object's access right.
     *  On successful write, return no of written bytes.
     *  Incase of Error return valid error code.
     *       -EACCES: In case access is not valid.
     *       -EINVAL: If write end is already closed.
     *       -EOTHERS: For any other errors.
     *
     */
    //  printk("w\n");
    if(filep==NULL)
    {
        return -EOTHERS;
    }
    if(buff==NULL)
    {
        return -EOTHERS;
    }
     int bytes_written = 0;
    struct pipe_info* curPipe= filep->pipe;
   if(curPipe==NULL)
    {
        return -EOTHERS;
    }
    int cur_read=curPipe->pipe_global.read_ptr;
    int cur_write=curPipe->pipe_global.write_ptr;
    char *cur_buffer=curPipe->pipe_global.pipe_buff;
    int buf_size=MAX_PIPE_SIZE;
    int data_written=curPipe->pipe_global.written;
    if(count>=(MAX_PIPE_SIZE-data_written))
        count=MAX_PIPE_SIZE-data_written;
//    printk("w0\n");
    if(is_valid_mem_range((long unsigned int)buff,count,2)!=1)
    {
        // printk("INtrupe %d\n",is_valid_mem_range((long unsigned int)buff,count,2));
        return -EACCES;

    }


    struct exec_context *current = get_current_ctx();

      int flag=0;
    //   printk("w1\n");
    for(int i=0;i<MAX_PIPE_PROC;i++)
    {
        if(filep->pipe->pipe_per_proc[i].pid==current->pid)
        {
            flag++;
            if(filep->pipe->pipe_per_proc[i].write_open==0)
            {
                return -EINVAL;
            }
        }
    }
    //  printk("w2\n");
    if(flag==0)
    {
        return -EOTHERS;
    }
   
   
    // printk("From do_write: readpointer=%d, writepointer=%d , written=%d , count=%d \n",cur_read,cur_write,curPipe->pipe_global.written,count);
    while((bytes_written<count))
    {
        //  printk("w3\n");
        cur_buffer[cur_write]=buff[bytes_written];
        cur_write++;
        bytes_written++;
        curPipe->pipe_global.written++;
        cur_write%=MAX_PIPE_SIZE;
    }
    //  printk("w4\n");
    curPipe->pipe_global.write_ptr=cur_write;
    // printk("From do_write: cur_write=%d\n",cur_write);

    return bytes_written;
}

// Function to create pipe.
// struct file{
// 	u32 type;
// 	u32 mode;
// 	u32 offp;
// 	u32 ref_count;
// 	struct inode * inode;
// 	struct fileops * fops;
// 	struct pipe_info * pipe;
// 	struct ppipe_info *ppipe;
// 	struct msg_queue_info *msg_queue;
// };
int create_pipe (struct exec_context *current, int *fd) 
{

    
    /**
     *  TODO:: Implementation of Pipe Create
     *
     *  Find two free file descriptors.
     *  Create two file objects for both ends by invoking the alloc_file() function. 
     *  Create pipe_info object by invoking the alloc_pipe_info() function and
     *       fill per process and global info fields.
     *  Fill the fields for those file objects like type, fops, etc.
     *  Fill the valid file descriptor in *fd param.
     *  On success, return 0.
     *  Incase of Error return valid Error code.
     *       -ENOMEM: If memory is not enough.
     *       -EOTHERS: Some other errors.
     *
     */
    // Simple return.
    
    struct file *fileRead=alloc_file();
    struct file *fileWrite=alloc_file();
    struct pipe_info *pipeInfo = alloc_pipe_info();
        //to check if memoery is available for a pipe

    if(pipeInfo==NULL||fileRead==NULL||fileWrite==NULL)
    {
        return  -ENOMEM;
    }

    if(current==NULL)
    {
        return -EOTHERS;
    }
    if(pipeInfo->pipe_global.pipe_buff==NULL)
    {
        return -ENOMEM;    
    }

    fileRead->type = PIPE;
	fileRead->mode =  O_READ;
	fileRead->offp = 0;
    fileRead->ref_count=1;
	fileRead->fops->read = pipe_read;
	fileRead->fops->write = pipe_write;
	fileRead->fops->close = pipe_close;
    fileRead->pipe=pipeInfo;


    fileWrite->type = PIPE;
	fileWrite->mode =  O_WRITE;
	fileWrite->offp = 0;
    fileWrite->ref_count=1;
	fileWrite->fops->read = pipe_read;
	fileWrite->fops->write = pipe_write;
	fileWrite->fops->close = pipe_close;
    fileWrite->pipe=pipeInfo;


    int fd1 = 0;
	while(fd1 < MAX_OPEN_FILES)
	{
		if(!current->files[fd1])
		{
				current->files[fd1] = fileRead;
				break;
		}
			fd1++;
	}
  
     int fd2 = 0;
	while(fd2< MAX_OPEN_FILES)
	{
		if(!current->files[fd2])
		{
				current->files[fd2] = fileWrite;
				break;
		}
			fd2++;
	}

    if(fd1==MAX_OPEN_FILES||fd2==MAX_OPEN_FILES)
    {
        return -EOTHERS;
    }
    fd[0]=fd1;
    fd[1]=fd2;
    return 0;
}
