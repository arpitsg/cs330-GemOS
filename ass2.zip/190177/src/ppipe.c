#include<ppipe.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>


//
// Per process information for the ppipe.
struct ppipe_info_per_process {

    // TODO:: Add members as per your need...
    int write_open;
    int read_open;
    int pid;
    int read_ptr;
    int written;

};
//
// Global information for the ppipe.
struct ppipe_info_global {

    char *ppipe_buff;       // Persistent pipe buffer: DO NOT MODIFY THIS.
    int total_proc;
    int write_ptr;
    int written; 

};

// Persistent pipe structure.
// NOTE: DO NOT MODIFY THIS STRUCTURE.
struct ppipe_info {

    struct ppipe_info_per_process ppipe_per_proc [MAX_PPIPE_PROC];
    struct ppipe_info_global ppipe_global;

};
void print_info(struct file *filep)
{


    // printk("GLOBAL INFO  OF PPIPE from current pid=%d\n",getpid());
    // struct ppipe_info* curPipe= filep->ppipe;
    
    // printk("total_proc=%d,write_ptr=%d,written=%d\n",curPipe->ppipe_global.total_proc,curPipe->ppipe_global.write_ptr,curPipe->ppipe_global.written);
    // printk("LOCAL INFO  OF PPIPE\n");
    // for(int i=0;i< MAX_PPIPE_PROC;i++)
    // {
    //     if(curPipe->ppipe_per_proc[i].pid!=-1)
    //     {
    //         printk("write_open=%d,read_open=%d,pid=%d\n,read_ptr=%d,written=%d\n",curPipe->ppipe_per_proc[i].write_open,curPipe->ppipe_per_proc[i].read_open,curPipe->ppipe_per_proc[i].pid,curPipe->ppipe_per_proc[i].read_ptr,curPipe->ppipe_per_proc[i].written);
    //     }

    // }
}
//
// Function to allocate space for the ppipe and initialize its members.
struct ppipe_info* alloc_ppipe_info() {

    // Allocate space for ppipe structure and ppipe buffer.
    struct ppipe_info *ppipe = (struct ppipe_info*)os_page_alloc(OS_DS_REG);
    char* buffer = (char*) os_page_alloc(OS_DS_REG);

     if(ppipe==NULL)
    {
        return ppipe;
    }
    // Assign ppipe buffer.
    ppipe->ppipe_global.ppipe_buff = buffer;

    /**
     *  TODO:: Initializing pipe fields
     *
     *  Initialize per process fields for this ppipe.
     *  Initialize global fields for this ppipe.
     *
     */ 
    // Return the ppipe.
    ppipe->ppipe_global.total_proc=1;
    ppipe->ppipe_global.write_ptr=0;
    ppipe->ppipe_global.written=0;

    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        ppipe->ppipe_per_proc[i].read_ptr=0;
        ppipe->ppipe_per_proc[i].written=0;
        ppipe->ppipe_per_proc[i].write_open=1;
        ppipe->ppipe_per_proc[i].read_open=1;
        ppipe->ppipe_per_proc[i].pid=-1;
    }
    struct exec_context *current = get_current_ctx();
    ppipe->ppipe_per_proc[0].pid=current->pid;
   

    return ppipe;

}

// Function to free ppipe buffer and ppipe info object.
// NOTE: DO NOT MODIFY THIS FUNCTION.
void free_ppipe (struct file *filep) {

    os_page_free(OS_DS_REG, filep->ppipe->ppipe_global.ppipe_buff);
    os_page_free(OS_DS_REG, filep->ppipe);

} 
////
// Fork handler for ppipe.
int do_ppipe_fork (struct exec_context *child, struct file *filep) {
    
    // printk("I am her\n");
    /**
     *  TODO:: Implementation for fork handler
     *
     *  You may need to update some per process or global info for the ppipe.
     *  This handler will be called twice since ppipe has 2 file objects.
     *  Also consider the limit on no of processes a ppipe can have.
     *  Return 0 on success.
     *  Incase of any error return -EOTHERS.
     *
     */
       
    // printk("START FORK\n\n");
    // print_info(filep);
      if(child==NULL ||filep==NULL)
    {
        return -EOTHERS;
    }
    
    struct ppipe_info* curPipe= filep->ppipe;

    if(curPipe==NULL)
    {
        return -EOTHERS;
    }

  //
    int k=0;
    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        if(curPipe->ppipe_per_proc[i].pid==child->pid)
        {            
             k=1;
        }
    }
   int index=0;
    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        if( curPipe->ppipe_per_proc[i].pid==child->ppid)
        {            
             index=i;
        }
    } //d

    
    if(k==0)
    {
         if( curPipe->ppipe_global.total_proc ==MAX_PPIPE_PROC)
         {
        //   printk("b %d\n",MAX_PIPE_PROC);
        return -EOTHERS;
        }
        curPipe->ppipe_global.total_proc++;
            for(int i=0;i<MAX_PPIPE_PROC;i++)
            {
                if(curPipe->ppipe_per_proc[i].pid==-1)
                {
                    curPipe->ppipe_per_proc[i].written=curPipe->ppipe_per_proc[index].written;                   
                    curPipe->ppipe_per_proc[i].read_ptr=curPipe->ppipe_per_proc[index].read_ptr;
                    curPipe->ppipe_per_proc[i].pid=child->pid;
                    curPipe->ppipe_per_proc[i].write_open=1;
                    curPipe->ppipe_per_proc[i].read_open=1;
                    break;
                }
            }
    }

   
    // printk("CLOSE FORK\n\n");
    // print_info(filep);
    return 0;
    // Return successfully.

}


// Function to close the ppipe ends and free the ppipe when necessary.
long ppipe_close (struct file *filep) {

    /**
     *  TODO:: Implementation of Pipe Close
     *
     *  Close the read or write end of the ppipe depending upon the file
     *      object's mode.
     *  You may need to update some per process or global info for the ppipe.
     *  Use free_pipe() function to free ppipe buffer and ppipe object,
     *      whenever applicable.
     *  After successful close, it return 0.
     *  Incase of any error return -EOTHERS.
     *                                                                          
     */
    // printk("Closing something\n");
    // printk("CLOSE START\n");
    // print_info(filep);
    if(filep==NULL)
    {
        return -EOTHERS;
    }
    int ret_value;
    struct ppipe_info* curPipe= filep->ppipe;
    struct exec_context *current = get_current_ctx();
      if(current==NULL)
    {
        return -EOTHERS;
    }
    if(curPipe==NULL)
    {
        return -EOTHERS;
    }
    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {

        if(curPipe->ppipe_per_proc[i].pid==current->pid)
        {
            // printk("mode->%d, O_WRITE=%d, O_READ=%d\n",filep->mode,O_WRITE,O_READ);
            if(filep->mode & O_WRITE)
            {
                if(curPipe->ppipe_per_proc[i].write_open==0)
                {
                      return -EOTHERS;
                }
                curPipe->ppipe_per_proc[i].write_open=0;
                // printk("Closed write\n");
            }
            if(filep->mode & O_READ)
            {
                  if(curPipe->ppipe_per_proc[i].read_open==0)
                {
                      return -EOTHERS;
                }
                curPipe->ppipe_per_proc[i].read_open=0;
                //  printk("Closed read\n");
            }
            if(curPipe->ppipe_per_proc[i].write_open==0  && curPipe->ppipe_per_proc[i].read_open==0 )
            {
                //  printk("reducing total process\n");
                curPipe->ppipe_global.total_proc--;
                curPipe->ppipe_per_proc[i].pid=-1;
                if( curPipe->ppipe_global.total_proc==0)
                {
                    // printk("Calling free_ppipe\n");
                    free_ppipe(filep);
                }
            }
        }
    }

    // Clos e the file and return.
    ret_value = file_close (filep);         // DO NOT MODIFY THIS LINE.
    
    // And return.
    // printk("CLOSE END\n");
    // print_info(filep);
    return ret_value;

}
//
// Function to perform flush operation on ppipe.
int do_flush_ppipe (struct file *filep) {

    /**
     *  TODO:: Implementation of Flush system call
     *
     *  Reclaim the region of the persistent pipe which has been read by 
     *      all the processes.
     *  Return no of reclaimed bytes.
     *  In case of any error return -EOTHERS.
     *
     */
    // printk("FLUSH START\n");
    // print_info(filep);
    if(filep==NULL)
    {
        return -EOTHERS;
    }
    int reclaimed_bytes = 0;
    struct ppipe_info* curPipe= filep->ppipe;
    int max=-1;
     for(int i=0;i<MAX_PPIPE_PROC;i++)
     {
        //  printk("i=%d, written=%d\n",i,curPipe->ppipe_per_proc[i].written);
        if(curPipe->ppipe_per_proc[i].pid!=-1 && curPipe->ppipe_per_proc[i].read_open==1)
        {
            if(curPipe->ppipe_per_proc[i].written>max)
            {
                max=curPipe->ppipe_per_proc[i].written;
            }
         }
     }
    if(max==-1)
    {
        return 0;
    }
     reclaimed_bytes=curPipe->ppipe_global.written-max;
     curPipe->ppipe_global.written=max;
    // Return reclaimed bytes.
    //  printk("FLUSH END\n");
    // print_info(filep);
    return reclaimed_bytes;

}

// Read handler for the ppipe.
int ppipe_read (struct file *filep, char *buff, u32 count) {
    
    /**
     *  TODO:: Implementation of PPipe Read
     *
     *  Read the data from ppipe buffer and write to the provided buffer.
     *  If count is greater than the present data size in the ppipe then just read
     *      that much data.
     *  Validate file object's access right.
     *  On successful read, return no of bytes read.
     *  Incase of Error return valid error code.
     *      -EACCES: In case access is not valid.
     *      -EINVAL: If read end is already closed.
     *      -EOTHERS: For any other errors.
     *
     */
    
       if(filep==NULL)
    {
        return -EOTHERS;
    }
    if(buff==NULL)
    {
        return -EOTHERS;
    }
    // printk("READ START\n");
    // print_info(filep);
    struct exec_context *current = get_current_ctx();
    if(current==NULL)
    {
        return -EOTHERS;
    }
     int flag=0;
     int index=-1;
    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        if(filep->ppipe->ppipe_per_proc[i].pid==current->pid)
        {
            flag++;
            index=i;
            // printk("current global write pointer=%d , per process written=%d,  global process written=%d\n",filep->ppipe->ppipe_global.write_ptr,filep->ppipe->ppipe_per_proc[i].written,filep->ppipe->ppipe_global.written);

            if(filep->ppipe->ppipe_per_proc[i].read_open==0)
            {
                return -EINVAL;
            }
        }
    }
    if(flag==0)
    {
        return -EOTHERS;
    }



    int bytes_read = 0;
    struct ppipe_info* curPipe= filep->ppipe;
   
    int cur_read=curPipe->ppipe_per_proc[index].read_ptr;
    int cur_write=curPipe->ppipe_global.write_ptr;
    char *cur_buffer=curPipe->ppipe_global.ppipe_buff;
    int buf_size=MAX_PPIPE_SIZE;
    int data_written=curPipe->ppipe_per_proc[index].written;

    if(count>=(data_written))
        count=data_written;    
    // printk("From do_read: readpointer=%d, writepointer=%d , written=%d , count=%d \n",cur_read,cur_write,curPipe->pipe_global.written,count);
     bytes_read=0;
    while((bytes_read<count))
    {
        buff[bytes_read]=cur_buffer[cur_read];
        cur_read++;
        bytes_read++;
        curPipe->ppipe_per_proc[index].written--;
        cur_read%=MAX_PPIPE_SIZE;
    }

    curPipe->ppipe_per_proc[index].read_ptr=cur_read;
    // Return no of bytes read.
    // printk("READ END\n");
    // print_info(filep);
    return bytes_read;
	
}

// Write handler for ppipe.
int ppipe_write (struct file *filep, char *buff, u32 count) {

    /**
     *  TODO:: Implementation of PPipe Write
     *
     *  Write the data from the provided buffer to the ppipe buffer.
     *  If count is greater than available space in the ppipe then just write
     *      data that fits in that space.
     *  Validate file object's access right.
     *  On successful write, return no of written bytes.
     *  Incase of Error return valid error code.
     *      -EACCES: In case access is not valid.
     *      -EINVAL: If write end is already closed.
     *      -EOTHERS: For any other errors.
     *
     */
    // printk("current global write pointer=%d ,   global process written=%d\n",filep->ppipe->ppipe_global.write_ptr,filep->ppipe->ppipe_global.written);

    // printk("WRITE START\n");
    // print_info(filep);

    if(filep==NULL)
    {
        return -EOTHERS;
    }
    if(buff==NULL)
    {
        return -EOTHERS;
    }
     int bytes_written = 0;
    struct ppipe_info* curPipe= filep->ppipe;
   if(curPipe==NULL)
    {
        return -EOTHERS;
    }
    int cur_write=curPipe->ppipe_global.write_ptr;
    char *cur_buffer=curPipe->ppipe_global.ppipe_buff;
    int buf_size=MAX_PPIPE_SIZE;
    int data_written=curPipe->ppipe_global.written;
    if(count>=(MAX_PPIPE_SIZE-data_written))
        count=MAX_PPIPE_SIZE-data_written;
   //
    // printk("count=%d, MAX_PPIPE_SIZE=%d,data_written=%d\n",count,MAX_PPIPE_SIZE,data_written);

        
    struct exec_context *current = get_current_ctx();

      int flag=0;
    for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        if(filep->ppipe->ppipe_per_proc[i].pid==current->pid)
        {
            flag++;
            if(filep->ppipe->ppipe_per_proc[i].write_open==0)
            {
                return -EINVAL;
            }
        }
    }
    if(flag==0)
    {
        return -EOTHERS;
    }
   
   
    // printk("From do_write: readpointer=%d, writepointer=%d , written=%d , count=%d \n",cur_read,cur_write,curPipe->pipe_global.written,count);
    while((bytes_written<count))
    {
        cur_buffer[cur_write]=buff[bytes_written];
        cur_write++;
        bytes_written++;
        curPipe->ppipe_global.written++;
        cur_write%=MAX_PPIPE_SIZE;
    }
     for(int i=0;i<MAX_PPIPE_PROC;i++)
    {
        if(curPipe->ppipe_per_proc[i].pid!=-1)
            curPipe->ppipe_per_proc[i].written+=bytes_written;
    }
    curPipe->ppipe_global.write_ptr=cur_write;
    // printk("From do_write: cur_write=%d\n",cur_write);

    // printk("WRITE END\n");
    // print_info(filep);
    return bytes_written;
//





}

// Function to create persistent pipe.
int create_persistent_pipe (struct exec_context *current, int *fd) {

    /**
     *  TODO:: Implementation of PPipe Create
     *
     *  Find two free file descriptors.
     *  Create two file objects for both ends by invoking the alloc_file() function.
     *  Create ppipe_info object by invoking the alloc_ppipe_info() function and
     *      fill per process and global info fields.
     *  Fill the fields for those file objects like type, fops, etc.
     *  Fill the valid file descriptor in *fd param.
     *  On success, return 0.
     *  Incase of Error return valid Error code.
     *      -ENOMEM: If memory is not enough.
     *      -EOTHERS: Some other errors.
     *
     */
    struct file *fileRead=alloc_file();
    struct file *fileWrite=alloc_file();
    
    struct ppipe_info *ppipeInfo = alloc_ppipe_info();
        //to check if memory is available for a pipe
     if(ppipeInfo==NULL||fileRead==NULL||fileWrite==NULL)
    {
        return  -ENOMEM;
    }
    if(current==NULL)
    {
        return -EOTHERS;
    }
    if(ppipeInfo->ppipe_global.ppipe_buff==NULL)
    {
        return -ENOMEM;    
    }

    fileRead->type = PPIPE;
	fileRead->mode =  O_READ;
	fileRead->offp = 0;
    fileRead->ref_count=1;
	fileRead->fops->read = ppipe_read;
	fileRead->fops->write = ppipe_write;
	fileRead->fops->close = ppipe_close;
    fileRead->ppipe=ppipeInfo;


    fileWrite->type = PPIPE;
	fileWrite->mode =  O_WRITE;
	fileWrite->offp = 0;
    fileWrite->ref_count=1;
	fileWrite->fops->read = ppipe_read;
	fileWrite->fops->write = ppipe_write;
	fileWrite->fops->close = ppipe_close;
    fileWrite->ppipe=ppipeInfo;


    int fd1 = 0;
	while(fd1 < MAX_OPEN_FILES)
	{
		if(!current->files[fd1])
		{
				current->files[fd1] = fileRead;
				break;
		}
			fd1++;
	}
    //
     int fd2 = 0;
	while(fd2< MAX_OPEN_FILES)
	{
		if(!current->files[fd2])
		{
				current->files[fd2] = fileWrite;
				break;
		}
			fd2++;
	}
    if(fd1==MAX_OPEN_FILES||fd2==MAX_OPEN_FILES)
    {
        return -EOTHERS;
    }
    fd[0]=fd1;
    fd[1]=fd2;
    return 0;
    // Simple return.

}
