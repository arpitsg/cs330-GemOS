//TODO
// return value of f1 when flag on.


#include <debug.h>
#include <context.h>
#include <entry.h>
#include <lib.h>
#include <memory.h>


/*****************************HELPERS******************************************/

/*
 * allocate the struct which contains information about debugger
 *
 */
struct debug_info *alloc_debug_info()
{
	struct debug_info *info = (struct debug_info *) os_alloc(sizeof(struct debug_info));
	if(info )
		bzero((char *)info, sizeof(struct debug_info));
	return info;
}
/*
 * frees a debug_info struct
 */
void free_debug_info(struct debug_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct debug_info));
}



/*
 * allocates a page to store registers structure
 */
struct registers *alloc_regs()
{
	struct registers *info = (struct registers*) os_alloc(sizeof(struct registers));
	if(info)
		bzero((char *)info, sizeof(struct registers));
	return info;
}

/*
 * frees an allocated registers struct
 */
void free_regs(struct registers *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct registers));
}

/*
 * allocate a node for breakpoint list
 * which contains information about breakpoint
 */
struct breakpoint_info *alloc_breakpoint_info()
{
	struct breakpoint_info *info = (struct breakpoint_info *)os_alloc(
		sizeof(struct breakpoint_info));
	if(info)
		bzero((char *)info, sizeof(struct breakpoint_info));
	return info;
}
struct fun *alloc_fun()
{
	struct fun *info = (struct fun *)os_alloc(
		sizeof(struct fun));
	if(info)
		bzero((char *)info, sizeof(struct fun));
	return info;
}

/*
 * frees a node of breakpoint list
 */
void free_breakpoint_info(struct breakpoint_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct breakpoint_info));
}

void free_alloc_fun(struct fun *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct fun));
}
/*
 * Fork handler.
 * The child context doesnt need the debug info
 * Set it to NULL
 * The child must go to sleep( ie move to WAIT state)
 * It will be made ready when the debugger calls wait
 */
void debugger_on_fork(struct exec_context *child_ctx)
{
	// printk("DEBUGGER FORK HANDLER CALLED\n");
	child_ctx->dbg = NULL;
	child_ctx->state = WAITING;
}

////
void copy_registers(struct exec_context* p_ctx, struct exec_context* child) 
{
	struct registers copy_regs;
	copy_regs.r15 = child->regs.r15;
	copy_regs.r14 = child->regs.r14;
	copy_regs.r13 = child->regs.r13;
	copy_regs.r12 = child->regs.r12;
	copy_regs.r11 = child->regs.r11;
	copy_regs.r10 = child->regs.r10;
	copy_regs.r9 = child->regs.r9;
	copy_regs.r8 = child->regs.r8;
	copy_regs.rbp = child->regs.rbp;
	copy_regs.rdi = child->regs.rdi;
	copy_regs.rsi = child->regs.rsi;
	copy_regs.rdx = child->regs.rdx;
	copy_regs.rcx = child->regs.rcx;
	copy_regs.rbx = child->regs.rbx;
	copy_regs.rax = child->regs.rax;
	copy_regs.entry_rip = child->regs.entry_rip-1;
	copy_regs.entry_cs = child->regs.entry_cs;
	copy_regs.entry_rflags = child->regs.entry_rflags;
	copy_regs.entry_rsp = child->regs.entry_rsp;
	copy_regs.entry_ss = child->regs.entry_ss;
	
	p_ctx->dbg->copy_regs = copy_regs;

	return;
}

void bt_update_fun(struct exec_context* p_ctx, struct exec_context* child) 
{
	// printk("Entry:  bt_update_fun\n");
	int idx=0;
	u64 *bt=p_ctx->dbg->bt;
	bt[idx] = child->regs.entry_rip-1;
	idx=1;
	u64 rbp = child->regs.rbp;
	u64 ret_addr = *(u64 *)child->regs.entry_rsp;
	struct fun * tail=NULL;
	while(ret_addr != END_ADDR) {
		bt[idx] =  ret_addr;
		idx=idx+1;
		ret_addr = *(u64 *)(rbp+8);
		if(ret_addr==p_ctx->dbg->end_handler)
		{
			 struct fun * cur_fn=p_ctx->dbg->active_fn;

			 while(cur_fn->next!=tail)
			 {
				 cur_fn=cur_fn->next;
			 }
			 tail=cur_fn;
			 ret_addr=cur_fn->overwrite;
		}
		rbp = *(u64 *)rbp;
	} 
	p_ctx->dbg->bt_size = idx;
	// printk("Exit:  bt_update_fun : idx=%d\n",idx);

	return ;
}
void bt_update_end(struct exec_context* p_ctx, struct exec_context* child) 
{
	int idx=0;
	u64 *bt=p_ctx->dbg->bt;
	u64 rbp = child->regs.rbp;
   
	u64 ret_addr = *(u64 *)child->regs.entry_rsp;
	struct fun * tail=NULL;
	while(ret_addr != END_ADDR) {
		bt[idx] =  ret_addr;
		idx=idx+1;
		ret_addr = *(u64 *)(rbp+8);
		if(ret_addr==p_ctx->dbg->end_handler)
		{
			 struct fun * cur_fn=p_ctx->dbg->active_fn;

			 while(cur_fn->next!=tail)
			 {
				 cur_fn=cur_fn->next;
			 }
			 tail=cur_fn;
			 ret_addr=cur_fn->overwrite;
		}
		rbp = *(u64 *)rbp;
	} 
	p_ctx->dbg->bt_size = idx;
	p_ctx->dbg->bt_size = idx;
	return ;
}
/******************************************************************************/


/* This is the int 0x3 handler
 * Hit from the childs context
 */




long int3_handler(struct exec_context *ctx)
{   // printk("In int3_handler\n");
    if(ctx==NULL) return -1;
    int ppid = ctx->ppid;
    struct exec_context* parent_ctx = get_ctx_by_pid(ppid);
    struct breakpoint_info *curr=parent_ctx->dbg->head;
    int found=0;
    while(curr!=NULL)
    {
        if((curr->addr) == (ctx->regs.entry_rip-1))
        {
            found=1;
            break;
        }
        curr=curr->next;
    }
    u64 addr = ctx->regs.entry_rip;
    parent_ctx->regs.rax = addr-1; 
    if((ctx->regs.entry_rip-1)==(parent_ctx->dbg->end_handler))//top of end_handler function
    {
        // printk("her:3\n");
    	
		u64 addr_ow;
        struct fun * cur_fn=parent_ctx->dbg->active_fn;
        if(cur_fn->next==NULL)
        {
			addr_ow=cur_fn->overwrite;
			// printk("\n \n \n removing from call stack: %x\n\n\n",cur_fn->addr);

            free_alloc_fun(cur_fn);
            parent_ctx->dbg->active_fn=NULL;
        }
        else
        {
            while(cur_fn->next->next!=NULL)
            {
                cur_fn=cur_fn->next;
            }
			addr_ow=cur_fn->next->overwrite;
			// printk("\n \n \n removing from call stack: %x\n\n\n",cur_fn->next->addr);
            free_alloc_fun(cur_fn->next);
            cur_fn->next=NULL;
        }
		ctx->regs.entry_rsp -=8;
	    u64 do_end_handler_top = ctx->regs.entry_rsp;
        *(u64 *)do_end_handler_top = addr_ow;
		copy_registers(parent_ctx,ctx);
        bt_update_end(parent_ctx,ctx);
    }
    else if(found==1)//top of debugee function 
    {
        // printk("her:2\n");
		copy_registers(parent_ctx,ctx);
        bt_update_fun(parent_ctx,ctx);
        // printk("her:5\n");
      
        if(curr->end_breakpoint_enable==1) //and end_breakpoint_enable
        {
            // printk("10\n");
            // ctx->regs.entry_rsp -=8;
           
                // printk("address val=%x",*(u64 *)ctx->regs.entry_rsp);
            struct fun * active_fn =alloc_fun();
            active_fn->addr=ctx->regs.entry_rip-1;
			active_fn->overwrite= *(u64 *)ctx->regs.entry_rsp;
            active_fn->next=NULL;
			// printk("overwrite address=%x\n",active_fn->overwrite);
			 u64 do_end_handler_top = ctx->regs.entry_rsp;
            *(u64 *)do_end_handler_top = parent_ctx->dbg->end_handler;

            struct fun * cur_fn=parent_ctx->dbg->active_fn;
			// printk("\n \n \n Insert to call stack: %x\n\n\n",active_fn->addr);

            if(cur_fn==NULL)
            {
                // printk("11\n");
                parent_ctx->dbg->active_fn=active_fn;
            }
            else
            {   
                while(cur_fn->next!=NULL)
                {
                cur_fn=cur_fn->next;
                }
                cur_fn->next=active_fn;
            }   
        }
    }
    else //no breakpoint found if called from debugee function
    {
        // printk("her:1\n");
        return -1;
    }
        // printk("her:4\n");
    ctx->regs.entry_rsp -=8;
    u64 stack_top = ctx->regs.entry_rsp;
    *(u64 *) stack_top = ctx->regs.rbp;
    ctx->state = WAITING;
    parent_ctx->state = READY;
    schedule(parent_ctx);
    return 0;   
}

/*
 * Exit handler.
 * Deallocate the debug_info struct if its a debugger.
 * Wake up the debugger if its a child
 */
void debugger_on_exit(struct exec_context *ctx)
{
	if(ctx==NULL)
		return;
	struct debug_info *cur_debug_info=ctx->dbg;

	if(ctx->dbg!=NULL) //kill debugger
	{
		// printk("debugger_on_exit\n");
		struct breakpoint_info *head_node=cur_debug_info->head;
		while(head_node!=NULL)
		{
			struct breakpoint_info* next = head_node->next;
			head_node->next=NULL;
			free_breakpoint_info(head_node);
			head_node = next;
		}
		struct fun *fun_node=cur_debug_info->active_fn;
		while(fun_node!=NULL)
		{
			struct fun* next = fun_node->next;
			fun_node->next=NULL;
			free_alloc_fun(fun_node);
			fun_node = next;
		}
		free_debug_info(ctx->dbg);
		ctx->dbg=NULL;
	}
	else 
	{
		
		struct exec_context* parent_ctx = get_ctx_by_pid(ctx->ppid);
		parent_ctx->regs.rax=CHILD_EXIT;
		parent_ctx->state = READY;
	}
		return;

}


/*
 * called from debuggers context
 * initializes debugger state
 */
int do_become_debugger(struct exec_context *ctx, void *addr)
{
	// printk("In become_debugger\n");
	struct debug_info *cur_debug_info;
	cur_debug_info = alloc_debug_info();
	if(cur_debug_info == NULL) return -1;
	cur_debug_info->breakpoint_count=0;
	cur_debug_info->head=NULL;
	cur_debug_info->active_fn=NULL;
	cur_debug_info->end_handler=addr;
	cur_debug_info->br_num=1;
	ctx->dbg=cur_debug_info;
	*((u8*)addr) = INT3_OPCODE;	
	return 0;
}
/*
 * called from debuggers context
 */
int do_set_breakpoint(struct exec_context *ctx, void *addr, int flag)
{
	

	if(ctx==NULL||ctx->dbg == NULL)
	{
		return -1;
	}
	struct debug_info *cur_debug_info=ctx->dbg;
	struct breakpoint_info *cur_bp_info=alloc_breakpoint_info();
	if(cur_bp_info==NULL)
	{
		return -1;
	}
	struct breakpoint_info *head_node=cur_debug_info->head;

	//check if same address already present

	struct fun * cur_fn=ctx->dbg->active_fn;
	int err_check=0;
	while(cur_fn!=NULL)
	{
		// printk("cur_fn->addr=%x\n",cur_fn->addr);
		if(cur_fn->addr==(u64)addr && flag==0)
		{
			err_check=-1;
		}
	cur_fn=cur_fn->next;
	}
	if(err_check==-1)
	{
		free_breakpoint_info(cur_bp_info);
		return -1; //changing state of breakpoint from 1 to 0 in stack. 
	}	
	int present=0;

	while(head_node!=NULL)
	{
		// printk("head_node->addr=%x::::addr=%x  \n",head_node->addr,(u64)addr);
		if(head_node->addr==(u64)addr)
		{
			present=1;
			break;
		}
		head_node=head_node->next;
	}

	if(present)
	{
		// printk("present");
		free_breakpoint_info(cur_bp_info);
		head_node->end_breakpoint_enable=flag;
		// printk("flag=%d\n",flag);
		// printk("here\n");
		return 0;
	}
	
	if(MAX_BREAKPOINTS==cur_debug_info->breakpoint_count)
	{
		free_breakpoint_info(cur_bp_info);
		return -1;
	}

	cur_debug_info->breakpoint_count++;
	//assign cur_bp_info
	cur_bp_info->num=cur_debug_info->br_num;
	cur_debug_info->br_num++;
	cur_bp_info->addr=(u64)addr; 
	// printk("address set=%x\n",cur_bp_info->addr);
	cur_bp_info->next=NULL;
	cur_bp_info->end_breakpoint_enable=flag;
	// insert INT3
	*((u8*)addr) = INT3_OPCODE;
	//find last breakpoint
	struct breakpoint_info *node=cur_debug_info->head;
	if(cur_debug_info->head==NULL)//no breakpoint present
	{
		cur_debug_info->head=cur_bp_info;
	}
	else
	{
		while(node->next!=NULL)
		{
			node=node->next;
		}
		node->next=cur_bp_info;
	}

	return 0;
}


/*
 * called from debuggers context
 */
int do_remove_breakpoint(struct exec_context *ctx, void *addr)
{
	// printk("In do_remove_breakpoint\n");
	if(ctx==NULL) return -1; 
	if(ctx->dbg==NULL) return -1; 
	struct debug_info *cur_debug_info=ctx->dbg;
	
	struct breakpoint_info *node=cur_debug_info->head;

	//error check
	if(node->end_breakpoint_enable==1)
	{
		int flag=0;
		struct fun * active_fn=ctx->dbg->active_fn;
		while(active_fn!=NULL)
		{
			// printk("in remove: active_fn->addr=%x,addr=%x\n",active_fn->addr,addr);
			if(active_fn->addr==addr)
			{
				// printk("Here\n");
				flag=1;
			}
			active_fn=active_fn->next;
		}
		// printk("flag=%d\n",flag);
		if(flag)
		{
			// printk("-480\n");
			return -1;
		}
	}

	int present=0;
	while(node!=NULL)
	{
		if(node->addr==(u64)addr)
		{
			present=1;
			break;
		}
		node=node->next;
	}

	if(present==0)
	{
		// printk("-498\n");
		return -1; 
	}




	if(node==cur_debug_info->head)
	{
		cur_debug_info->head=node->next;
	}
	else
	{
		struct breakpoint_info *temp_node=cur_debug_info->head;
		while(temp_node->next!=node)
		{
			temp_node=temp_node->next;
		}
		temp_node->next=node->next;
		node->next=NULL;
	}

	
	free_breakpoint_info(node);
	cur_debug_info->breakpoint_count--;
	return 0;
}


/*
 * called from debuggers context
 */

int do_info_breakpoints(struct exec_context *ctx, struct breakpoint *ubp)
{
	if(ctx==NULL || ctx->dbg ==NULL) 
		return -1; 
	struct debug_info *cur_debug_info=ctx->dbg;
	struct breakpoint_info *curr=cur_debug_info->head;
	int count=0;
	while(curr!=NULL)
	{
		struct breakpoint ubp_curr;

		ubp_curr.num=curr->num;
		ubp_curr.end_breakpoint_enable=curr->end_breakpoint_enable;
		ubp_curr.addr=curr->addr;
		ubp[count] = ubp_curr;
		count++;
		curr=curr->next;
	}
	// Your code
	return count;
}


/*
 * called from debuggers context
 */
int do_info_registers(struct exec_context *ctx, struct registers *regs)
{
	if(ctx==NULL || ctx->dbg==NULL) return -1;
	*regs = ctx->dbg->copy_regs;
	return 0;
}

/*
 * Called from debuggers context
 */
int do_backtrace(struct exec_context *ctx, u64 bt_buf)
{
	if(ctx==NULL || ctx->dbg ==NULL) 
		return -1;
	u64* itr = (u64*) bt_buf;
	for(int i=0;i<ctx->dbg->bt_size;i++) {
		itr[i] = ctx->dbg->bt[i];
	}
	return ctx->dbg->bt_size;
}
//
/*
 * When the debugger calls wait
 * it must move to WAITING state
 * and its child must move to READY state
 */

s64 do_wait_and_continue(struct exec_context *ctx)
{
		// printk("In do_wait_and_continue\n");
	if(ctx==NULL || ctx->dbg==NULL) return -1;

	struct exec_context *child;
	int found=0;
	for(int pid=1;pid<=MAX_PROCESSES;pid++)
	{
		child = get_ctx_by_pid(pid);		
		if(child!=NULL &&child->ppid==ctx->pid)
		{ 
			// printk("Found\n");
			break;
		}
	}
	if(child==NULL || child->state==UNUSED )
	{
		// printk("EXITOTOTITOT\n");
		return CHILD_EXIT; /////make a elementin structure

	}
	ctx->state = WAITING;
	child->state = READY;

	schedule(child);
	/////checkkkkkkkkkkkkkkk//
	return -1;
}






