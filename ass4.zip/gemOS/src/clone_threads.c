#include<clone_threads.h>
#include<entry.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<mmap.h>

/* 
  system call handler for clone, create thread like 
  execution contexts. Returns pid of the new context to the caller. 
  The new context starts execution from the 'th_func' and 
  use 'user_stack' for its stack
*/
long do_clone(void *th_func, void *user_stack, void *user_arg) 
{
  // printk("do_clone\n");


  struct exec_context *new_ctx = get_new_ctx();
  struct exec_context *ctx = get_current_ctx();
   ctx->type = EXEC_CTX_USER;
  u32 pid = new_ctx->pid;
  
  if(!ctx->ctx_threads){  // This is the first thread
          ctx->ctx_threads = os_alloc(sizeof(struct ctx_thread_info));
          bzero((char *)ctx->ctx_threads, sizeof(struct ctx_thread_info));
          ctx->ctx_threads->pid = ctx->pid;
  } 
     
 /* XXX Do not change anything above. Your implementation goes here*/
  
  
  // allocate page for os stack in kernel part of process's VAS
  // The following two lines should be there. The order can be 
  // decided depending on your logic.
    // printk("Inside do_clone!\n");
    // printk("Funct address=%x",(u64)th_func);
    //    printk("user_stack address=%x",(u64)user_stack);
    // printk("user_arg address=%x\n",(u64)user_arg);
    *new_ctx = *ctx;  //Copy the process
	new_ctx->pid = pid;
	new_ctx->ppid = ctx->pid; 
  
  
   

  //  printk("copying\n",(u64)user_arg);
	// copy_mm(new_ctx, ctx);
	setup_child_context(new_ctx);
  // printk("Copied\n",(u64)user_arg);

   
   new_ctx->type = EXEC_CTX_USER_TH;    // Make sure the context type is 
   new_ctx->regs.entry_rsp=(u64)user_stack;
  // *(u64 *) new_ctx->regs.entry_rsp= ctx->regs.entry_rip;
   new_ctx->regs.entry_rip=(u64)th_func;
   new_ctx->regs.rdi=(u64)user_arg;
   new_ctx->regs.rbp=(u64)user_stack;
   new_ctx->state=WAITING;
   

   struct ctx_thread_info *tinfo = ctx->ctx_threads;
   int found=0;
 struct thread *th;
    for(int i=0; i<MAX_THREADS; ++i)
    { 
        th = &tinfo->threads[i];
        if(!th||th->status==TH_UNUSED)
        {
          found=1;
           th->pid=pid;
           th->status=TH_USED;
           th->parent_ctx=ctx;
            break;
        }
       
   } 
   
  if(found==0)
  {
    // printk("Not found\n");
    return -1;
  }


  //  new_ctx->state = UNUSED;            // For the time being. Remove it as per your need.
// printk("returning pid=%x\n",pid);
// printk("new_ctx->ctx_threads->pid=%x\n",new_ctx->ctx_threads->pid);
	return pid;

}
static struct thread_private_map *find_thmap_custom(struct thread *th, u64 address)
{
 int ctr;
 struct thread_private_map *thmap = &th->private_mappings[0];
 for(ctr = 0; ctr < MAX_PRIVATE_AREAS; ++ctr, thmap++)
 {

      if(thmap->owner!=NULL && thmap->start_addr<=address && address<(thmap->start_addr+thmap->length))
      {
        return thmap;
      }
      
 } 
 return NULL;
}
struct thread* find_thread_from_address_custom(struct exec_context *ctx, u64 addr, struct thread_private_map **thmap)
{
   int i;
   struct thread *th;
   struct thread_private_map *map = NULL;
   
   struct ctx_thread_info *tinfo = ctx->ctx_threads;

   if(!isProcess(ctx) || !tinfo)
          return NULL;
   
   for(i=0; i<MAX_THREADS; ++i){
        th = &tinfo->threads[i];
        if(th->status == TH_USED && (map = find_thmap_custom(th, addr))){
              *thmap = map;
               return th;        
        }
   } 
 return NULL;
}
/*This is the page fault handler for thread private memory area (allocated using 
 * gmalloc from user space). This should fix the fault as per the rules. If the the 
 * access is legal, the fault handler should fix it and return 1. Otherwise it should
 * invoke segfault_exit and return -1*/

int handle_thread_private_fault(struct exec_context *current, u64 addr, int error_code)
{


// printk("handle_thread_private_fault pid=%d,error_code=%x\n",current->pid,error_code);
  int proc_pid=current->pid;
  struct thread* cur_thread;
  int fullaccess=0;
  struct thread_private_map *thmap = NULL;

   if(!isProcess(current))
   {
    //  printk("here1\n");
     struct exec_context *parent=get_ctx_by_pid(current->ppid);
     cur_thread= find_thread_from_address_custom(parent,addr,&thmap);
      if(!cur_thread)
      {
          segfault_exit(current->pid, current->regs.entry_rip, addr);
            return -1;
      }
   }
   else
   {
    //  printk("here2\n");
     fullaccess=1;
   }
  // printk("cur_thread->pid=%d",cur_thread->pid);
  
   if(fullaccess==0&&cur_thread->pid==current->pid)
   {
    //  printk("here3\n");
      fullaccess=1;
   }
    
    int flags=-1;
    if(thmap)
    {
      flags=thmap->flags;
    }
    // printk("flags=%x\n",flags);

    if(fullaccess==0&&flags==0x13)
    {
        segfault_exit(current->pid, current->regs.entry_rip, addr);
        return -1;
      
    }
      if(error_code==0x7&&fullaccess==0)
    {
        segfault_exit(current->pid, current->regs.entry_rip, addr);
        return -1;
    }

    if(flags==0x23 && (error_code==0x6) && fullaccess==0)
    {
       segfault_exit(current->pid, current->regs.entry_rip, addr);
        return -1;
    }
  

  
//   printk("Error code=%d\n",error_code);
//    /* your implementation goes here*/
//    printk("current->pgd=%x\n",current->pgd);
//  printk(" (u64)osmap(current->pgd)=%x\n", (u64)osmap(current->pgd));
    u64 base = (u64)osmap(current->pgd);
    u64 mask=0xFF8000000000;
    u64 shift=39;
    u64 pgd=(u64)base;
    u64 offset= ((addr&mask)>>shift);
    // printk("(u64*)((u64*)pgd + offset)==NULL=%d",(u64*)((u64*)pgd + offset)==NULL);
     if(*(u64*)((u64*)pgd + offset)==0x0)
    {
      u64 new_pfn = os_pfn_alloc(USER_REG);
      bzero((char*)new_pfn,4096);
      *(u64*)((u64*)pgd + offset)=((u64)osmap(new_pfn));
    }
    *(u64*)((u64*)pgd + offset)= *(u64*)((u64*)pgd + offset)|7;
    u64 pgd_T=*(u64*)((u64*)pgd + offset);
    // printk("offset=%x\n",offset);
    // printk("base=%x\n",base);
    // printk("address=%x\n",((u64*)pgd + offset));
    // printk("pgd_T=%x\n",pgd_T);



    base=(u64)osmap((pgd_T>>12));
    mask=mask>>9;
    shift-=9;//30
    u64 pud=(u64)base;
    offset= ((addr&mask)>>shift);
        // printk("(u64*)((u64*)pud + offset)==NULL=%d",(u64*)((u64*)pud + offset)==NULL);

    if( *(u64*)((u64*)pud + offset)==0x0)
    {
       u64 new_pfn = os_pfn_alloc(USER_REG);
       bzero((char*)new_pfn,4096);
       *(u64*)((u64*)pud + offset)=((u64)osmap(new_pfn));
    }
    *(u64*)((u64*)pud + offset)=*(u64*)((u64*)pud + offset)|7;
    u64 pud_T=*(u64*)((u64*)pud + offset);
    //  printk("offset=%x\n",offset);
    // printk("base=%x\n",base);
    // printk("address=%x\n",((u64*)pud + offset));
    // printk("pud_T=%x\n",pud_T);



    base=(u64)osmap((pud_T>>12));
    mask=mask>>9;
    shift-=9;//21
    u64 pmd=(u64)base;
    offset= ((addr&mask)>>shift);
    // printk("(u64*)((u64*)pmd + offset)==NULL=%d",(u64*)((u64*)pmd + offset)==NULL);
     if(  *(u64*)((u64*)pmd + offset)==0x0)
    {
      u64 new_pfn = os_pfn_alloc(USER_REG);
      bzero((char*)new_pfn,4096);
       *(u64*)((u64*)pmd + offset)=((u64)osmap(new_pfn));
    }
    *(u64*)((u64*)pmd + offset)=*(u64*)((u64*)pmd + offset)|7;
    u64 pmd_T=*(u64*)((u64*)pmd + offset);
    //   printk("offset=%x\n",offset);
    // printk("base=%x\n",base);
    // printk("address=%x\n",((u64*)pmd + offset));
    // printk("pud_T=%x\n",pmd_T);

    
    base=(u64)osmap((pmd_T>>12));
    mask=mask>>9;
    shift-=9;//12
    u64 pte=(u64)base;
    offset= ((addr&mask)>>shift);
    // printk("(u64*)((u64*)pte + offset)==NULL=%d",(u64*)((u64*)pte + offset)==NULL);
    if(*(u64*)((u64*)pte + offset)==0x0)
    {
      u64 new_pfn = os_pfn_alloc(USER_REG);
      bzero((char*)new_pfn,4096);
      *(u64*)((u64*)pte + offset)=((u64)osmap(new_pfn));
    }
    if(flags==0x23&&fullaccess==0)
    {
      *(u64*)((u64*)pte + offset)=*(u64*)((u64*)pte + offset)|5;
    }
    else
    {
       *(u64*)((u64*)pte + offset)=*(u64*)((u64*)pte + offset)|7;
    }
      u64 pte_T=*(u64*)((u64*)pte + offset);

    // printk("pte_T=%x\n",pte_T);
    // printk("offset=%x\n",offset);
    // printk("base=%x\n",base);
    // printk("address=%x\n",((u64*)pte + offset));

    return 1;
    

    segfault_exit(current->pid, current->regs.entry_rip, addr);
    return -1;
}

/*This is a handler called from scheduler. The 'current' refers to the outgoing context and the 'next' 
 * is the incoming context. Both of them can be either the parent process or one of the threads, but only
 * one of them can be the process (as we are having a system with a single user process). This handler
 * should apply the mapping rules passed in the gmalloc calls. */
void update_mapping( struct exec_context *current, struct thread *th1,int issibling)
{
  for(int i=0;i<MAX_PRIVATE_AREAS;i++)
   {
      if(th1->private_mappings[i].owner!=NULL)
      {
           u64 addr=th1->private_mappings[i].start_addr;
           int flags=th1->private_mappings[i].flags;
           do
           {
              u64 base = (u64)osmap(current->pgd);
              u64 mask=0xFF8000000000;
              u64 shift=39;
              for(int level=1;level<=4;level++)
              {
                // printk("base=%x\n",base);
                u64 curr=(u64)base;
                u64 offset= ((addr&mask)>>shift);
                if(*(u64*)((u64*)curr + offset)==0x0)
                {
                  break;
                }
                // printk("before=%x\n",*(u64*)((u64*)curr + offset));
                base=(u64)osmap(*(u64*)((u64*)curr + offset)>>12);
               
                if(level==4 && issibling)
                {
                  if(flags==0x13)
                  {
                    *(u64*)((u64*)curr + offset)=(((*(u64*)((u64*)curr + offset))>>3)<<3);
                  }
                  if(flags==0x23)
                  {

                     *(u64*)((u64*)curr + offset)=(((*(u64*)((u64*)curr + offset))>>3)<<3)|0x5;
                  }
                  if(flags==0x43)
                  {

                     *(u64*)((u64*)curr + offset)=(((*(u64*)((u64*)curr + offset))>>3)<<3)|0x7;
                  }
                  
                }
                else if(level==4)
                {
                   *(u64*)((u64*)curr + offset)=(((*(u64*)((u64*)curr + offset))>>3)<<3)|0x7;
                }
                else
                {
                  *(u64*)((u64*)curr + offset)=((*(u64*)((u64*)curr + offset)))|0x7;
                }
                // printk("after=%x\n",*(u64*)((u64*)curr + offset));
                mask=mask>>9;
                shift-=9;
              }
              asm volatile ("invlpg (%0);" 
                  :: "r"(addr) 
                  : "memory"); 
              addr+=0x1000;
           }while(addr<(th1->private_mappings[i].start_addr+th1->private_mappings[i].length));
      }
   }
}
int handle_private_ctxswitch(struct exec_context *current, struct exec_context *next)
{
  // printk("\nhandle_private_ctxswitch\n");
  if(next->pid==current->ppid) //thread to parent
  {
    // printk("sib to parent\n");
    int ppid=current->ppid;
      struct exec_context *parent=get_ctx_by_pid(ppid);
      struct thread *th1;
      for(int i=0;i<MAX_THREADS;i++)
      {
        th1= &parent->ctx_threads->threads[i];
        if(th1->pid==current->pid)
        {
          break;
        }
      }
      update_mapping(current,th1,0);
  }
  else if(current->pid==next->ppid)//parent to thread
  {
        // printk(" parent to sib\n");

        struct thread *th;
        for(int i=0;i<MAX_THREADS;i++)
        {
          th= &current->ctx_threads->threads[i];
          
          if(th->pid==next->pid) //this is next thread make permission or with 7
          {
             update_mapping(current,th,0);
          }
          else //this is sibling thread make permission case wise
          {
             update_mapping(current,th,1);
          }
        }
  }

  else
  {
    // printk("sib to sib\n");
      int ppid=current->ppid;
      struct exec_context *parent=get_ctx_by_pid(ppid);
      struct thread *th1;
      for(int i=0;i<MAX_THREADS;i++)
      {
        th1= &parent->ctx_threads->threads[i];
        if(th1->pid==current->pid)
        {
          //  printk("th1 pid found\n");
          break;
        }
      }
      update_mapping(current,th1,1);
  }
   


  
  

   return 0;	

}
