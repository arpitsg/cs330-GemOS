#include <gthread.h>
#include <ulib.h>
static struct process_thread_info tinfo __attribute__((section(".user_data"))) = {};
/*XXX 
      Do not modifiy anything above this line. The global variable tinfo maintains user
      level accounting of threads. Refer gthread.h for definition of related structs.
 */
void returnfinder()
{
	u64 ret;
	asm volatile(
		"mov %%rax, %0;"
		: "=r" (ret) 
		:
		: 
	);
	
	for(int i=0;i<MAX_THREADS;i++)
	{
		if(tinfo.threads[i].pid==getpid()&&tinfo.threads[i].status!=TH_STATUS_EXITED)
		{
			tinfo.threads[i].ret_addr=(u64*)ret;
			tinfo.threads[i].status=TH_STATUS_EXITED;
			tinfo.num_threads--;
			// printf("In returnfinder ,tinfo.threads[%d].ret_addr=%x  for pid=%d\n",i,tinfo.threads[i].ret_addr,getpid());

			break;
		}
	}

	exit(0);


}

/* Returns 0 on success and -1 on failure */
/* Here you can use helper system call "make_thread_ready" for your implementation */

int gthread_create(int *tid, void *(*fc)(void *), void *arg) {
        
	void *stackp;
	int thpid;

	stackp = mmap(NULL, TH_STACK_SIZE, PROT_READ|PROT_WRITE, 0);
	
	int found=0; 
	for(int i=0;i<MAX_THREADS;i++)
	{
		if(tinfo.threads[i].status!=TH_STATUS_EXITED &&tinfo.threads[i].status!=TH_STATUS_USED)
		{
			found=1;
			tinfo.num_threads++;
			tinfo.threads[i].tid=i;
			*tid=i;
			// printf("&returnfinder=%x,returnfinder=%x\n",&returnfinder,returnfinder);
			tinfo.threads[i].ret_addr=NULL;;
			tinfo.threads[i].stack_addr=stackp;
			for(int j=0;j<MAP_TH_PRIVATE;j++)
			{
					tinfo.threads[i].priv_areas[j].owner=NULL;
					tinfo.threads[i].priv_areas[j].start=0;
					tinfo.threads[i].priv_areas[j].length=0;
					tinfo.threads[i].priv_areas[j].flags=0;
			}			

			*(u64 *) ((u64)stackp+TH_STACK_SIZE-8) = (u64)returnfinder;
  
			int ret =clone(fc, ((u64)stackp)+TH_STACK_SIZE-8, arg);

			if(ret==-1)
               return -1;
	        tinfo.threads[i].pid=ret;
			tinfo.threads[i].status=TH_STATUS_USED;
			tinfo.num_threads+=1;
			make_thread_ready(ret);
			break;
		}
	}
	if(found==0)
	{
		return -1;
	}	
	return 0;
	
}


int gthread_exit(void *retval) 
{

	/* You need to fill in your implementation here*/
	

    	// printf("Ret value in gthread_exit=%d \n",*(s64*)retval);

	for(int i=0;i<MAX_THREADS;i++)
	{
		if(tinfo.threads[i].pid==getpid()&&tinfo.threads[i].status!=TH_STATUS_EXITED)
		{
			
			tinfo.threads[i].ret_addr=(u64*)retval;
			tinfo.threads[i].status=TH_STATUS_EXITED;
			break;
		}
	}

	// change structure values
	//call exit
	exit(0);
}

void* gthread_join(int tid) {
        
     /* Here you can use helper system call "wait_for_thread" for your implementation */
       
     /* You need to fill in your implementation here*/
	 u64* ret;
			int i=tid;
			// printf("tinfo.threads[i].status=%x\n",tinfo.threads[i].status);
			if(tinfo.threads[i].status==TH_STATUS_UNUSED)
			{
				return NULL;
			}
			// printf("gthread_join : tid=%d, pid=%d\n",tinfo.threads[i].tid,tinfo.threads[i].pid);
			
			// printf("retval=%d\n",retval);
			// printf("tinfo.threads[i].status=%d\n",tinfo.threads[i].status);
			
			if(tinfo.threads[i].status==TH_STATUS_USED)
			{
				int retval=wait_for_thread(tinfo.threads[i].pid);
				if(retval<0)
				{
					// printf("here1 ,pid=%d,tinfo.threads[%d].ret_addr=%x\n",tinfo.threads[i].pid,i,tinfo.threads[i].ret_addr);
					tinfo.num_threads--;
					tinfo.threads[i].status=TH_STATUS_UNUSED;
					munmap(tinfo.threads[i].stack_addr,TH_STACK_SIZE);
					return tinfo.threads[i].ret_addr;
				}
				int count=0;
				while(wait_for_thread(tinfo.threads[i].pid)==0)count++;
				// printf("No of loops =%d",count);
				retval=wait_for_thread(tinfo.threads[i].pid);
				if(retval<0)
				{
					// printf("here2\n");
					tinfo.num_threads--;
					tinfo.threads[i].status=TH_STATUS_UNUSED;
					munmap(tinfo.threads[i].stack_addr,TH_STACK_SIZE);
					return tinfo.threads[i].ret_addr;
					
				}
				return NULL;
			}
			while(wait_for_thread(tinfo.threads[i].pid)==0);
		    int retval=wait_for_thread(tinfo.threads[i].pid);

			tinfo.num_threads--;
			tinfo.threads[i].status=TH_STATUS_UNUSED;
			munmap(tinfo.threads[i].stack_addr,TH_STACK_SIZE);
			return tinfo.threads[i].ret_addr;
				
			
	
}
 

/*Only threads will invoke this. No need to check if its a process
 * The allocation size is always < GALLOC_MAX and flagss can be one
 * of the alloc flagss (GALLOC_*) defined in gthread.h. Need to 
 * invoke mmap using the proper protection flagss (for prot param to mmap)
 * and MAP_TH_PRIVATE as the flags param of mmap. The mmap call will be 
 * handled by handle_thread_private_map in the OS.
 * */

void* gmalloc(u32 size, u8 alloc_flags)
{
   u8 prot=PROT_READ|PROT_WRITE;
   u64 addr;
   if(alloc_flags==GALLOC_OWNONLY)
   {
	   prot|=TP_SIBLINGS_NOACCESS;
	   addr=	(u64)mmap(NULL,size,prot,MAP_TH_PRIVATE);
   }
  else if(alloc_flags==GALLOC_OTRDONLY)
  {
	   prot|=TP_SIBLINGS_RDONLY;
		addr=(u64)mmap(NULL,size,prot,MAP_TH_PRIVATE);

  }
  else if(alloc_flags==GALLOC_OTRDWR)
  {
	  prot|=TP_SIBLINGS_RDWR;
	  addr=(u64)mmap(NULL,size,prot,MAP_TH_PRIVATE);

  }
  else
  {
	  return NULL;
  }
  if(!addr || addr == MAP_ERR){
      return NULL;
  }
  for(int i=0;i<MAX_THREADS;i++)
	{
		if(tinfo.threads[i].pid==getpid())
		{
			for(int j=0;j<MAP_TH_PRIVATE;j++)
			{
				if(	tinfo.threads[i].priv_areas[j].owner==NULL)
				{
					tinfo.threads[i].priv_areas[j].owner=&tinfo.threads[i];
					tinfo.threads[i].priv_areas[j].start=addr;
					tinfo.threads[i].priv_areas[j].length=size;
					tinfo.threads[i].priv_areas[j].flags=prot;
				}
			}
			break;
		}
	}
	return addr;

}
/*
   Only threads will invoke this. No need to check if the caller is a process.
*/
int gfree(void *ptr)
{
   
    for(int i=0;i<MAX_THREADS;i++)
	{
		if(tinfo.threads[i].pid==getpid())
		{
			for(int j=0;j<MAP_TH_PRIVATE;j++)
			{
				if(	tinfo.threads[i].priv_areas[j].owner==&tinfo.threads[i] && 	tinfo.threads[i].priv_areas[j].start==(u64)ptr)
				{
					tinfo.threads[i].priv_areas[j].owner=NULL;
					if(munmap(ptr,tinfo.threads[i].priv_areas[j].length)<0)
					{
						return -1;
					}
					return 0;
				}	
			}
		}
	}
     	return -1;
}
